export default {
    // You can add configuration variables here if needed.
};

